 lightGallery(document.getElementById('lightgallery'));
 lightGallery(document.getElementById('lightgallery1'));
 lightGallery(document.getElementById('lightgallery2'));